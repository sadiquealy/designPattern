// VisitorPattern.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include<string>
#include <fstream>
#include <iostream>
using namespace std;

class Ram;
class MotherBoard;
class KeyBoard;
class Mouse;
class Computer;


class IComputerVisitor
{
public:
	virtual ~IComputerVisitor() {}
	virtual void Visit(Ram& ram) = 0;
	virtual void Visit(MotherBoard& board) = 0;
	virtual void Visit(KeyBoard& kboard) = 0;
	virtual void Visit(Mouse& mouse) = 0;
	virtual void Visit(Computer& mouse) = 0;
};

class IVisitable
{
	virtual void Accept(IComputerVisitor* visitor) = 0;
};

class Ram : public IVisitable
{
public:
	Ram(const string& sName, int nCapacity):m_sName(sName),m_nCapacity(nCapacity)
	{

	}
public:
	
	string m_sName;
	int m_nCapacity;

	// Inherited via IVisitable
	virtual void Accept(IComputerVisitor * visitor) override
	{
		visitor->Visit(*this);
	}
};

class MotherBoard: public IVisitable
{
public:
	MotherBoard(const string& sName) :m_sName(sName)
	{

	}
public:
	// Inherited via IVisitable
	virtual void Accept(IComputerVisitor * visitor) override
	{
		visitor->Visit(*this);
	}

	string m_sName;
};

class KeyBoard : public IVisitable
{
public:
	KeyBoard(const string& sName) :m_sName(sName)
	{

	}
public:
	// Inherited via IVisitable
	virtual void Accept(IComputerVisitor * visitor) override
	{
		visitor->Visit(*this);
	}

	string m_sName;

};

class Mouse : public IVisitable
{
public:
	Mouse(const string& sName) :m_sName(sName)
	{

	}
public:
	// Inherited via IVisitable
	virtual void Accept(IComputerVisitor * visitor) override
	{
		visitor->Visit(*this);
	}

	string m_sName;
	int m_nWheels = 1;
};


class Computer : public IVisitable
{
public:
	Computer(const string& sName) :m_sName(sName)
	{
		m_Ram      = unique_ptr<Ram>(new Ram("KingSton", 8));
		m_MotherBoard      = unique_ptr<MotherBoard>(new MotherBoard("Giga Byte"));
		m_KeyBoard = unique_ptr<KeyBoard>(new KeyBoard("IBall"));
		m_Mouse    = unique_ptr<Mouse>(new Mouse("Logitech"));
	}
public:
	void Accept(IComputerVisitor* visitor)
	{
		visitor->Visit(*this);
		m_Ram->Accept(visitor);
		m_MotherBoard->Accept(visitor);
		m_KeyBoard->Accept(visitor);
		m_Mouse->Accept(visitor);
	}

	string m_sName;
private:
	std::unique_ptr<Ram> m_Ram;	
	std::unique_ptr<MotherBoard> m_MotherBoard;
	std::unique_ptr<KeyBoard> m_KeyBoard;
	std::unique_ptr<Mouse> m_Mouse;
};


class FileVisitor : public IComputerVisitor
{
public:
	FileVisitor(const string& sFile)
	{
		m_File.open(sFile.c_str(), ios::out | ios::trunc);
	}
	~FileVisitor()
	{
		m_File.close();
	}
	// Inherited via IComputervisitor
	virtual void Visit(Ram & ram) override
	{
		m_File << "\nRam company is:" << ram.m_sName;
		m_File << "\nRam Capacity is:" << ram.m_nCapacity;
	}

	// Inherited via IComputervisitor
	virtual void Visit(MotherBoard & mboard) override
	{
		m_File << "\nMotherBoard company is:" << mboard.m_sName;
	}

	// Inherited via IComputervisitor
	virtual void Visit(KeyBoard & kboard) override
	{
		m_File << "\nKeyBoard company is:" << kboard.m_sName;
	}

	// Inherited via IComputervisitor
	virtual void Visit(Mouse & mouse) override
	{
		m_File << "\nMouse company is:" << mouse.m_sName;
	}

	// Inherited via IComputervisitor
	virtual void Visit(Computer & compueter) override
	{
		m_File << "Computer name is:" << compueter.m_sName;
	}
private:
	ofstream m_File;
};

class ConsoleVisitor : public IComputerVisitor
{
public:
	// Inherited via IComputervisitor
	virtual void Visit(Ram & ram) override
	{
		cout << "\nRam company is:" << ram.m_sName;
		cout << "\nRam Capacity is:" << ram.m_nCapacity;
	}

	// Inherited via IComputervisitor
	virtual void Visit(MotherBoard & mboard) override
	{
		cout << "\nMotherBoard company is:" << mboard.m_sName;
	}

	// Inherited via IComputervisitor
	virtual void Visit(KeyBoard & kboard) override
	{
		cout << "\nKeyBoard company is:" << kboard.m_sName;
	}

	// Inherited via IComputervisitor
	virtual void Visit(Mouse & mouse) override
	{
		cout << "\nMouse company is:" << mouse.m_sName;
	}

	// Inherited via IComputervisitor
	virtual void Visit(Computer & compueter) override
	{
		cout << "Computer name is:" << compueter.m_sName;
	}
};

int main()
{
	std::unique_ptr<IComputerVisitor> pVisitorConsole = unique_ptr<ConsoleVisitor>(new ConsoleVisitor());  
	std::unique_ptr<IComputerVisitor> pVisitorFile    = unique_ptr<FileVisitor>(new FileVisitor("D:\\VisitLog.txt"));
	Computer computer("Intel");
	computer.Accept(pVisitorConsole.get());
	computer.Accept(pVisitorFile.get()); 
}

